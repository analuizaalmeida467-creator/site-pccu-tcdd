import React from 'react';

function SummaryTable() {
  const rows = [{'faixa': '<20', 'AGC-US': 0, 'ALTERADO': 0, 'ASC-H': 0, 'ASC-US': 0, 'HSIL': 0, 'INSATISFAT': 0, 'LSIL': 0, 'NEGATIVO': 0, 'total_faixa': 0}, {'faixa': '20-29', 'AGC-US': 0, 'ALTERADO': 0, 'ASC-H': 5, 'ASC-US': 3, 'HSIL': 1, 'INSATISFAT': 0, 'LSIL': 1, 'NEGATIVO': 77, 'total_faixa': 87}, {'faixa': '30-39', 'AGC-US': 1, 'ALTERADO': 0, 'ASC-H': 5, 'ASC-US': 2, 'HSIL': 5, 'INSATISFAT': 1, 'LSIL': 1, 'NEGATIVO': 196, 'total_faixa': 211}, {'faixa': '40-49', 'AGC-US': 0, 'ALTERADO': 1, 'ASC-H': 7, 'ASC-US': 8, 'HSIL': 6, 'INSATISFAT': 3, 'LSIL': 7, 'NEGATIVO': 358, 'total_faixa': 390}, {'faixa': '50+', 'AGC-US': 0, 'ALTERADO': 0, 'ASC-H': 6, 'ASC-US': 7, 'HSIL': 5, 'INSATISFAT': 3, 'LSIL': 5, 'NEGATIVO': 308, 'total_faixa': 334}];
  return (
    <table style={width:'100%',borderCollapse:'collapse'}>
      <thead>
        <tr>
          <th style={textAlign:'left',padding:'8px',borderBottom:'1px solid #eee'}>faixa</th><th style={textAlign:'left',padding:'8px',borderBottom:'1px solid #eee'}>AGC-US</th><th style={textAlign:'left',padding:'8px',borderBottom:'1px solid #eee'}>ALTERADO</th><th style={textAlign:'left',padding:'8px',borderBottom:'1px solid #eee'}>ASC-H</th><th style={textAlign:'left',padding:'8px',borderBottom:'1px solid #eee'}>ASC-US</th><th style={textAlign:'left',padding:'8px',borderBottom:'1px solid #eee'}>HSIL</th><th style={textAlign:'left',padding:'8px',borderBottom:'1px solid #eee'}>INSATISFAT</th><th style={textAlign:'left',padding:'8px',borderBottom:'1px solid #eee'}>LSIL</th><th style={textAlign:'left',padding:'8px',borderBottom:'1px solid #eee'}>NEGATIVO</th><th style={textAlign:'left',padding:'8px',borderBottom:'1px solid #eee'}>total_faixa</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r, i) => (
          <tr key={i}>
            <td style={padding:'8px',borderBottom:'1px solid #f6f6f6'}>{r['faixa']}</td><td style={padding:'8px',borderBottom:'1px solid #f6f6f6'}>{r['AGC-US']}</td><td style={padding:'8px',borderBottom:'1px solid #f6f6f6'}>{r['ALTERADO']}</td><td style={padding:'8px',borderBottom:'1px solid #f6f6f6'}>{r['ASC-H']}</td><td style={padding:'8px',borderBottom:'1px solid #f6f6f6'}>{r['ASC-US']}</td><td style={padding:'8px',borderBottom:'1px solid #f6f6f6'}>{r['HSIL']}</td><td style={padding:'8px',borderBottom:'1px solid #f6f6f6'}>{r['INSATISFAT']}</td><td style={padding:'8px',borderBottom:'1px solid #f6f6f6'}>{r['LSIL']}</td><td style={padding:'8px',borderBottom:'1px solid #f6f6f6'}>{r['NEGATIVO']}</td><td style={padding:'8px',borderBottom:'1px solid #f6f6f6'}>{r['total_faixa']}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default function App() {
  return (
    <div className="container">
      <header className="header">
        <h1 style={margin:0}>Relação entre Comportamentos de Prevenção, Faixa Etária e Alterações Citológicas no PCCU</h1>
        <div className="small">Ana Luiza Parente De Almeida et al. — Macapá - AP (2024)</div>
      </header>

      <div className="grid">
        <main>
          <div className="card">
            <h2>Resumo</h2>
            <p className="small">O estudo analisou resultados do PCCU coletados em 2024, buscando relação entre faixa etária e alterações citológicas, e fatores psicossociais que afetam adesão ao exame.</p>
          </div>

          <div className="card">
            <h2>Resultados — Tabela resumida</h2>
            <SummaryTable />
          </div>

          <div className="card">
            <h2>Downloads</h2>
            <p><a href="/artigo-pccu.pdf" target="_blank" rel="noreferrer">Baixar artigo completo (PDF)</a></p>
            <p><a href="/dados.csv" target="_blank" rel="noreferrer">Baixar dados (CSV)</a></p>
          </div>
        </main>

        <aside>
          <div className="card">
            <h3>Gráficos</h3>
            <div style={marginBottom:12}><img src="/assets/percent_alterado_faixa.png" alt="percent" style={width:'100%'}/></div>
            <div style={marginBottom:12}><img src="/assets/contagem_resultados.png" alt="contagem" style={width:'100%'}/></div>
            <div><img src="/assets/hist_idades.png" alt="hist" style={width:'100%'}/></div>
          </div>

          <div className="card">
            <h3>Estatísticas</h3>
            <div className="small">
              <p>N = 1022</p>
              <p>Média de idade (todas): 44.83</p>
            </div>
          </div>
        </aside>
      </div>

      <footer style={textAlign:'center',marginTop:24,color:'#888'}>
        <small>Gerado automaticamente — pronto para publicar na Vercel.</small>
      </footer>
    </div>
  );
}
